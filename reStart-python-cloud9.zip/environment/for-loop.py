print("Count to 10!")
for x in range (0, 11, 3):
    print(x)